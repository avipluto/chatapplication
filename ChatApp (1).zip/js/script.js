
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");

    function validateEmail(email) {
        return /\S+@\S+\.\S+/.test(email);
    }

    function validatePassword(password) {
        return password.length >= 6;
    }

    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            const email = document.getElementById("email");
            const password = document.getElementById("password");

            if (!validateEmail(email.value)) {
                e.preventDefault();
                email.classList.add("is-invalid");
            } else {
                email.classList.remove("is-invalid");
            }

            if (!validatePassword(password.value)) {
                e.preventDefault();
                password.classList.add("is-invalid");
            } else {
                password.classList.remove("is-invalid");
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener("submit", function (e) {
            const email = document.getElementById("email");
            const password = document.getElementById("password");

            if (!validateEmail(email.value)) {
                e.preventDefault();
                email.classList.add("is-invalid");
            } else {
                email.classList.remove("is-invalid");
            }

            if (!validatePassword(password.value)) {
                e.preventDefault();
                password.classList.add("is-invalid");
            } else {
                password.classList.remove("is-invalid");
            }
        });
    }
});
